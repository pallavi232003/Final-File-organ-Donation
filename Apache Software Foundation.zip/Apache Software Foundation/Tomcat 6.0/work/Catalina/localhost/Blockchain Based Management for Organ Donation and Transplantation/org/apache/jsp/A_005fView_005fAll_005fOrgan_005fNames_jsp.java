package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.sql.*;
import java.util.*;

public final class A_005fView_005fAll_005fOrgan_005fNames_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/connect.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n");
      out.write("<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n");
      out.write("<head>\r\n");
      out.write("<title>A_View_All_Organ_Names</title>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n");
      out.write("<link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/coin-slider.css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/cufon-yui.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/cufon-chunkfive.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.4.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/script.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/coin-slider.min.js\"></script>\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write("<!--\r\n");
      out.write(".style1 {font-size: 36px}\r\n");
      out.write(".style2 {font-size: 16px}\r\n");
      out.write(".style3 {color: #FFFFFF}\r\n");
      out.write(".style4 {color: #FF00FF}\r\n");
      out.write(".style5 {color: #FF0000}\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"main\">\r\n");
      out.write("  <div class=\"header\">\r\n");
      out.write("    <div class=\"header_resize\">\r\n");
      out.write("      <div class=\"menu_nav\">\r\n");
      out.write("        <ul>\r\n");
      out.write("          <li><a href=\"index.html\"><span>Home Page</span></a></li>\r\n");
      out.write("        </ul>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div class=\"clr\"></div>\r\n");
      out.write("      <div class=\"logo\">\r\n");
      out.write("        <h1><a href=\"index.html\" class=\"style1\">Enhancing Transparency in Organ Donation Through Blockchain Innovation</a></h1>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div class=\"searchform\"></div>\r\n");
      out.write("      <div class=\"clr\"></div>\r\n");
      out.write("      <div class=\"slider\">\r\n");
      out.write("        <div id=\"coin-slider\"> <a href=\"#\"><img src=\"images/slide1.jpg\" width=\"960\" height=\"360\" alt=\"\" /><span><big>Enhancing Transparency in Organ Donation Through Blockchain Innovation</big></span></a> <a href=\"#\"><img src=\"images/slide2.jpg\" width=\"960\" height=\"360\" alt=\"\" /><span><big>Enhancing Transparency in Organ Donation Through Blockchain Innovation</big></span></a> <a href=\"#\"><img src=\"images/slide3.jpg\" width=\"960\" height=\"360\" alt=\"\" /><span><big>Enhancing Transparency in Organ Donation Through Blockchain Innovation</big></span></a> </div>\r\n");
      out.write("        <div class=\"clr\"></div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div class=\"clr\"></div>\r\n");
      out.write("    </div>\r\n");
      out.write("  </div>\r\n");
      out.write("  <div class=\"content\">\r\n");
      out.write("    <div class=\"content_resize\">\r\n");
      out.write("      <div class=\"mainbar\">\r\n");
      out.write("        <div class=\"article\">\r\n");
      out.write("          <h2><span class=\"style4\">View All Blockchain Hashcode for Organ Name </span></h2>\r\n");
      out.write("          <p>&nbsp;</p>\r\n");
      out.write("          <table width=\"619\" align=\"center\"  cellpadding=\"0\" cellspacing=\"0\" >\r\n");
      out.write("            <tr>\r\n");
      out.write("              <td width=\"147\" height=\"37\" valign=\"middle\" bgcolor=\"#FF0000\" style=\"color: #2c83b0;\"><div align=\"center\" class=\"style27 style105 style65 style2 style3\"><em><strong>ID</strong></em></div></td>\r\n");
      out.write("              \r\n");
      out.write("              <td width=\"209\" valign=\"middle\" bgcolor=\"#FF0000\" style=\"color: #2c83b0;\"><div align=\"center\" class=\"style27 style105 style65 style2 style3\"><em><strong>Organ Name </strong></em></div></td>\r\n");
      out.write("              <td width=\"397\" valign=\"middle\" bgcolor=\"#FF0000\" style=\"color: #2c83b0;\"><div align=\"center\" class=\"style27 style105 style65 style2 style3\"><em><strong>Hash Code</strong></em></div></td>\r\n");
      out.write("\t\t\t</tr>\r\n");
      out.write("            ");
      out.write("\r\n");
      out.write("\r\n");

	Connection connection = null;
 	try {
     	

	  	Class.forName("com.mysql.jdbc.Driver");	
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/organ_donation","root","root");
      

	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	

      out.write("\r\n");
      out.write("            ");

					  
						String s1,s2,s3,s4,s5,s6,s7;
						int i=0;
						try 
						{
						   	String query="select * from organ_name"; 
						   	Statement st=connection.createStatement();
						   	ResultSet rs=st.executeQuery(query);
					   		while ( rs.next() )
					   		{
								i=rs.getInt(1);
								s1=rs.getString(2);
								s2=rs.getString(3);
								
								
					
      out.write("\r\n");
      out.write("            <tr bgcolor=\"#99CCFF\">\r\n");
      out.write("            \r\n");
      out.write("              \r\n");
      out.write("              <td height=\"67\"  align=\"center\"  valign=\"middle\" bgcolor=\"#FFFFFF\"><div align=\"center\" class=\"style71 style70 style20 style37 style54 style55 style86 style57 style5\"><strong>\r\n");
      out.write("                  ");
out.println(i);
      out.write("\r\n");
      out.write("              </strong></div></td>\r\n");
      out.write("              <td  align=\"center\"  valign=\"middle\" bgcolor=\"#FFFFFF\"><div align=\"center\" class=\"style71 style70 style20 style37 style54 style55 style86 style57 style5\"><strong>\r\n");
      out.write("                  ");
out.println(s1);
      out.write("\r\n");
      out.write("              </strong></div></td>\r\n");
      out.write("              <td align=\"center\"  valign=\"middle\" bgcolor=\"#FFFFFF\"><div align=\"center\" class=\"style71 style70 style20 style37 style54 style55 style86 style57 style5\"><strong>\r\n");
      out.write("                  ");
out.println(s2);
      out.write("\r\n");
      out.write("              </strong></div></td>\r\n");
      out.write("            </tr>\r\n");
      out.write("\t\t\t \r\n");
      out.write("\t\t\t\t\t\t");
	}
						
									
					connection.close();
					}
					catch(Exception e)
					{
						out.println(e);
					}
					
      out.write("\r\n");
      out.write("    </table>\r\n");
      out.write("\t  <p align=\"right\"><a href=\"Hospital_Main.jsp\">Back</a></p>\r\n");
      out.write("        </div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div class=\"clr\"></div>\r\n");
      out.write("    </div>\r\n");
      out.write("  </div>\r\n");
      out.write("  <div class=\"fbg\">\r\n");
      out.write("    <p>&nbsp;</p>\r\n");
      out.write("    <p>&nbsp;</p>\r\n");
      out.write("    <p>&nbsp;</p>\r\n");
      out.write("    <p>&nbsp;</p>\r\n");
      out.write("  </div>\r\n");
      out.write("  <div class=\"footer\">\r\n");
      out.write("    <div class=\"footer_resize\">\r\n");
      out.write("      <div style=\"clear:both;\"></div>\r\n");
      out.write("    </div>\r\n");
      out.write("  </div>\r\n");
      out.write("</div>\r\n");
      out.write("<div align=center></div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
